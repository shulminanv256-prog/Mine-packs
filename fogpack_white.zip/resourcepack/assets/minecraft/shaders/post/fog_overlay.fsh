#version 150

uniform sampler2D MainSampler;
uniform sampler2D OverlaySampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 scene   = texture(MainSampler,   texCoord);
    vec4 overlay = texture(OverlaySampler, texCoord);

    // Blend overlay onto scene using overlay's alpha
    vec3 blended = mix(scene.rgb, overlay.rgb, overlay.a * 0.72);
    fragColor = vec4(blended, scene.a);
}
