#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4  vertexColor;
in vec2  texCoord0;
in vec4  normal;

out vec4 fragColor;

const vec3  FOG_NEAR     = vec3(0.97, 0.97, 0.96);
const vec3  FOG_FAR      = vec3(0.85, 0.90, 0.95);
const float FOG_END      = 12.0;
const float BASE_OPACITY = 0.30;
const float MAX_OPACITY  = 0.96;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) discard;

    float t = clamp(vertexDistance / FOG_END, 0.0, 1.0);
    float distFog = 1.0 - exp(-t * t * 3.5);
    float fogFactor = clamp(BASE_OPACITY + distFog * (MAX_OPACITY - BASE_OPACITY), 0.0, MAX_OPACITY);
    vec3 fogRGB = mix(FOG_NEAR, FOG_FAR, distFog);
    color.rgb = mix(color.rgb, fogRGB, fogFactor);

    fragColor = color;
}
