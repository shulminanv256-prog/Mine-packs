#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4  vertexColor;
in vec2  texCoord0;
in vec4  normal;

out vec4 fragColor;

// ── FogPlugin — White Fog ─────────────────────────────────────────────────────
// Immersive "inside the fog" effect:
//   - BASE_OPACITY: constant white haze applied to ALL geometry regardless of
//     distance. Makes the world look misty even right next to the player.
//   - Distance fog: exponential curve that gets denser further away.
//   - Combined: player is always inside a white haze, thicker at distance.
// ─────────────────────────────────────────────────────────────────────────────

const vec3  FOG_NEAR    = vec3(0.97, 0.97, 0.96);  // warm cream (close)
const vec3  FOG_FAR     = vec3(0.85, 0.90, 0.95);  // cool blue-grey (far)
const float FOG_END     = 12.0;   // blocks where fog reaches max density
const float BASE_OPACITY = 0.30;  // base haze on ALL surfaces (0=none, 1=opaque)
const float MAX_OPACITY  = 0.96;  // max fog opacity at full distance

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) discard;

    // Distance fog: exponential, starts from 0
    float t = clamp(vertexDistance / FOG_END, 0.0, 1.0);
    float distFog = 1.0 - exp(-t * t * 3.5);

    // Total fog = base haze + distance contribution, clamped to MAX_OPACITY
    float fogFactor = clamp(BASE_OPACITY + distFog * (MAX_OPACITY - BASE_OPACITY), 0.0, MAX_OPACITY);

    // Fog color shifts from warm cream (near) to cool grey (far)
    vec3 fogRGB = mix(FOG_NEAR, FOG_FAR, distFog);

    color.rgb = mix(color.rgb, fogRGB, fogFactor);

    fragColor = color;
}
