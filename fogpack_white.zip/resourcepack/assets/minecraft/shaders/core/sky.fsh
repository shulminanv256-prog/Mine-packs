#version 150

uniform vec4 ColorModulator;
uniform vec4 FogColor;

in vec4 vertexColor;
out vec4 fragColor;

void main() {
    // Solid overcast sky — same tone as FOG_NEAR so horizon blends seamlessly
    fragColor = vec4(0.94, 0.94, 0.93, 1.0);
}
